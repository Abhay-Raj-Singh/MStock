import React from 'react';
  
const Logout = () => {
  return (
    <div
      style={{
        display: 'flex',
        justifyContent: 'Right',
        alignItems: 'Right',
        height: '100vh'
      }}
    >
      <h1>Logout</h1>
    </div>
  );
};
  
export default Logout;