import React, { useState } from "react";
import { Nav, NavLink, Heading, NavMenu } from "./NavbarElements";

const Navbar = () => {
  const handleLogout = () => {
    localStorage.clear();
    // window.location.reload(false);
  };

  const loggedInUser = localStorage.getItem("user");

  if (loggedInUser) {
    return (
      <>
        <Nav>
          <NavMenu>
            <Heading activeStyle>mStock</Heading>

            <NavLink to="/companies" activeStyle>
              Companies
            </NavLink>
            <NavLink to="/watchlist" activeStyle>
              Watch List
            </NavLink>
            <NavLink to="/comparePerformance" activeStyle>
              Compare Performance
            </NavLink>
            <NavLink
              to="/login"
              onClick={handleLogout}
              exact={true}
              activeStyle
            >
              Logout
            </NavLink>
          </NavMenu>
        </Nav>
      </>
    );
  } else {
    return (
      <>
        <Nav>
          <NavMenu>
            <Heading activeStyle>mStock</Heading>

            <NavLink to="/login">Login</NavLink>
            <NavLink to="/companies" activeStyle>
              Companies
            </NavLink>
          </NavMenu>
        </Nav>
      </>
    );
  }
};

export default Navbar;
